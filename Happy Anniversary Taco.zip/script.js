document.getElementById("password-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the form from submitting normally

    // Get the value entered in the password input field
    var password = document.getElementById("password").value;

    // Compare the entered password with the correct password
    if (password === "happyanniversarymylittletaco") { // Replace 'happyanniversarymylittletaco' with your correct password
        // Redirect to the new page
        window.location.href = "new_page.html"; // Replace 'new_page.html' with the URL of your new page
    } else {
        // Display an alert for incorrect password
        alert("Incorrect password. Please try again.");
    }
});
